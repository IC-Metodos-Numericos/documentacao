A estrutura está dividida em pastas para facilitar a organização e evitar que, caso você não tenha experiência, modifique acidentalmente alguma parte vital do código.

As pastas Capitulos e Preliminar são onde você vai escrever seu trabalho.

A pasta Preambulo pode ser usadas para adicionar novas estruturas de teoremas, novos pacotes e novos comandos.

A pasta libs não deve ser aberta se você não tiver uma experiência razoável com latex.

O arquivo Main reune todas as informações para compilar o trabalho. Nele você só preencherá coisas como: nome, nome do orientador, membros da banca etc.

Os hiperlinks irão aparecer de outra cor apenas para 